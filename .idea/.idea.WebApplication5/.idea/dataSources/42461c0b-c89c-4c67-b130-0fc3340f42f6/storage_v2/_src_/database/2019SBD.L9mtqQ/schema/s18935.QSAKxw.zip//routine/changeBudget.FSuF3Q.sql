Create procedure changeBudget 
@team varchar(30), 
@newBudget int
As
Begin 	  
		  update crew set budget = @newBudget where  id = (Select   id from crew where name  like @team);
		   
End
go

