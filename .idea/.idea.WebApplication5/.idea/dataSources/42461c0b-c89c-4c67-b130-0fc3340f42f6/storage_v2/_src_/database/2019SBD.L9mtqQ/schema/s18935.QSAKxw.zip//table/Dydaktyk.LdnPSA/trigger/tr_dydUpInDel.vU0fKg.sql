CREATE trigger tr_dydUpInDel on Dydaktyk 
After Update , insert, delete
As 
Begin 
	if exists (Select * from inserted) and not exists (Select * from deleted)
	Begin
		Update budzet set wartosc = (Select sum(placa ) from Dydaktyk)
	End
	If exists (Select * from deleted) and not exists (Select * from inserted)
	Begin 
			Update budzet set wartosc = (Select sum(placa ) from Dydaktyk)
	End 
	if exists (Select * from deleted) and exists (Select * from inserted)
	Begin 
		Update budzet set wartosc = (Select sum(placa ) from Dydaktyk)
	end
End
go

