 CREATE PROCEDURE zd_2
@Data date,
@val int output
AS
begin
Declare @info int; 
set @val =(Select count(1) from student inner join Osoba on Osoba.IdOsoba = Student.IdOsoba 
where Student.DataRekrutacji > Cast(@Data as date ))  
end
 go

