Create TRIGGER noChange ON engineHistory  
instead of Update  
AS  
begin  
  print('updating this table is not allowed to preserve data....');
End;

go

