CREATE PROCEDURE emp_add
@Datarekrutacji date
AS
Begin
Select Imie, nazwisko, miasto, NrIndeksu from Student inner join Osoba on Osoba.IdOsoba =  Student.IdOsoba where Year(DataRekrutacji) = Year(@Datarekrutacji); 
return
End
go

