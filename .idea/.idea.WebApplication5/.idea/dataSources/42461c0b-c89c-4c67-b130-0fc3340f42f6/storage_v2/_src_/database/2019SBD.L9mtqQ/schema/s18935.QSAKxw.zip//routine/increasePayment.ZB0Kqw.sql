CREATE procedure increasePayment 
@border int
as 
Begin	
	Declare @name varchar(30)
	Declare @lastname varchar(30)
	Declare @idOsoba varchar(30)
	Declare @placa int
	Declare myCursor Cursor for Select Osoba.IdOsoba, imie, nazwisko, placa from Osoba inner join Dydaktyk on Osoba.IdOsoba = Dydaktyk.IdOsoba 
	OPEN myCursor  
	FETCH NEXT FROM myCursor INTO @idOsoba, @name, @lastname, @placa  
		WHILE @@FETCH_STATUS = 0  
		BEGIN  
			 if @placa < @border 
			 Begin 
				Update Dydaktyk set placa = @placa + @placa *0.1 where @idOsoba = IdOsoba
				print(@name + 'placa obnizona')
			 End 
			 else
			 Begin 
			 	Update Dydaktyk set placa = @placa - @placa *0.1 where @idOsoba = IdOsoba
				print(@name + 'placa podwyszona')
			 End
			  FETCH NEXT FROM myCursor INTO @idOsoba, @name, @lastname, @placa 
		END 
	CLOSE myCursor  
	DEALLOCATE myCursor 
End
go

