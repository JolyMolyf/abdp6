

CREATE PROCEDURE emp_data AS
begin
SELECT ename, job, sal FROM EMP;
end

exec emp_data
go

