CREATE procedure sal_Increase 
@min_Sal int, 
@max_Sal int,
@count int output
as 
begin
Declare Test CURSOR FOR 
SELECT Dydaktyk.idOsoba, Imie, Nazwisko, Placa FROM Dydaktyk inner join Osoba on Dydaktyk.IdOsoba = Osoba.IdOsoba; 
DECLARE @id int,@ename Varchar(20), @nazwisko Varchar(20), @sal int; 
OPEN Test; FETCH NEXT FROM Test INTO @id, @ename, @nazwisko, @sal; 
WHILE @@FETCH_STATUS = 0 
BEGIN 
	if (@sal < @min_Sal)
			Begin 
			Update Dydaktyk set Placa = @sal + (@sal * 0.1) where IdOsoba = @id; 
			print( @ename + 'zostala obnizona');
			End
	if(@sal > @max_Sal)
			Begin
			Update Dydaktyk set Placa = @sal - (@sal * 0.1)  where IdOsoba = @id; 
			print( @ename + 'zostala podwyszina');
			End
	set @count = @@ROWCount
FETCH NEXT FROM Test INTO @id, @ename, @nazwisko, @sal; 
END; 
CLOSE Test; 
DEALLOCATE Test;
end;
go

